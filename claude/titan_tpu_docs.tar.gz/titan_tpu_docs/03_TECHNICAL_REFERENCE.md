# 03 - 技术规格详解

> 本文档包含 Titan-TPU V2 项目的所有技术细节，供开发和面试参考

---

## 📋 目录

1. [tiny-tpu-v2 源码分析](#1-tiny-tpu-v2-源码分析)
2. [PE 模块详解](#2-pe-模块详解)
3. [Systolic Array 详解](#3-systolic-array-详解)
4. [定点数系统 Q8.8](#4-定点数系统-q88)
5. [Control Unit 与 ISA](#5-control-unit-与-isa)
6. [ECC SECDED 技术规格](#6-ecc-secded-技术规格)
7. [Sparse 优化技术规格](#7-sparse-优化技术规格)
8. [AXI 接口技术规格](#8-axi-接口技术规格)
9. [时序约束与 PPA 目标](#9-时序约束与-ppa-目标)

---

## 1. tiny-tpu-v2 源码分析

### 1.1 文件依赖关系图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        tiny-tpu-v2 文件依赖关系                              │
└─────────────────────────────────────────────────────────────────────────────┘

                              tpu.sv (顶层)
                                   │
           ┌───────────────────────┼───────────────────────┐
           │                       │                       │
           ▼                       ▼                       ▼
    unified_buffer.sv       systolic.sv            control_unit.sv
           │                       │                       │
           │                       ▼                       │
           │                    pe.sv                      │
           │                       │                       │
           │                       ▼                       │
           │                fixedpoint.sv ◄────────────────┘
           │                       │
           │           ┌───────────┴───────────┐
           │           │                       │
           ▼           ▼                       ▼
        vpu.sv    bias_*.sv              leaky_relu_*.sv
           │           │                       │
           │           ▼                       ▼
           │    loss_*.sv            gradient_descent.sv
           │           │
           └───────────┴──────────────────────────────────────→ 训练支持
```

### 1.2 各文件功能说明

| 文件 | 行数 | 功能 | 依赖 | 重要性 |
|------|------|------|------|--------|
| `tpu.sv` | ~200 | TPU 顶层集成 | 所有模块 | ⭐⭐⭐⭐⭐ |
| `pe.sv` | ~100 | 处理单元 (MAC) | fixedpoint | ⭐⭐⭐⭐⭐ |
| `systolic.sv` | ~200 | 2×2 脉动阵列 | pe | ⭐⭐⭐⭐⭐ |
| `fixedpoint.sv` | ~400 | Q8.8 定点库 | 无 | ⭐⭐⭐⭐ |
| `unified_buffer.sv` | ~100 | 统一缓存 | 无 | ⭐⭐⭐⭐ |
| `control_unit.sv` | ~300 | 94位ISA控制器 | 无 | ⭐⭐⭐⭐ |
| `vpu.sv` | ~150 | 向量处理单元 | bias, relu, loss | ⭐⭐⭐ |
| `bias_*.sv` | ~100 | 偏置加法 | fixedpoint | ⭐⭐⭐ |
| `leaky_relu_*.sv` | ~100 | 激活函数 | fixedpoint | ⭐⭐⭐ |
| `loss_*.sv` | ~100 | 损失计算 | fixedpoint | ⭐⭐⭐ |
| `gradient_descent.sv` | ~100 | 梯度更新 | fixedpoint | ⭐⭐ |

### 1.3 数据流概览

```
输入数据                                                              输出数据
   │                                                                     ▲
   ▼                                                                     │
┌──────────────────────────────────────────────────────────────────────────────┐
│                              Unified Buffer                                  │
│  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐     │
│  │   Weight Memory    │  │  Activation Memory │  │   Output Memory    │     │
│  │   (存储权重矩阵)   │  │   (存储输入数据)   │  │   (存储计算结果)   │     │
│  └─────────┬──────────┘  └─────────┬──────────┘  └─────────▲──────────┘     │
└────────────┼─────────────────────────────────────────────────────────────────┘
             │                       │                       │
             ▼                       ▼                       │
        ┌────────────────────────────────────────────────────────────────┐
        │                     Systolic Array 2×2                          │
        │                                                                 │
        │   weights (从上方加载)                                          │
        │       ↓       ↓                                                 │
        │   ┌───────┬───────┐                                            │
        │   │ PE[0] │ PE[1] │ ← activations (从左侧流入)                  │
        │   │       │       │                                            │
        │   ├───────┼───────┤                                            │
        │   │ PE[2] │ PE[3] │                                            │
        │   │       │       │                                            │
        │   └───────┴───────┘                                            │
        │       ↓       ↓                                                 │
        │     partial sums (向下累加)                                     │
        │                                                                 │
        └─────────────────────────────────────────────────────┬──────────┘
                                                              │
                                                              ▼
        ┌────────────────────────────────────────────────────────────────┐
        │                          VPU                                    │
        │   ┌────────┐    ┌────────────┐    ┌────────┐                  │
        │   │  Bias  │ → │ Leaky ReLU │ → │  Loss  │ (训练时)          │
        │   └────────┘    └────────────┘    └────────┘                  │
        └─────────────────────────────────────────────────────┬──────────┘
                                                              │
                                                              ▼
                                                         最终输出
```

---

## 2. PE 模块详解

### 2.1 PE 架构图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PE (Processing Element)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   pe_weight_in ─────┐                                                       │
│   (16-bit)          │                                                       │
│                     ▼                                                       │
│                ┌─────────┐     pe_switch_in                                │
│                │ Weight  │ ◄───────────────── 切换信号                      │
│                │ Shadow  │                                                  │
│                │  Reg    │                                                  │
│                └────┬────┘                                                  │
│                     │                                                       │
│   pe_accept_w_in ───┼──────┐                                               │
│                     │      │                                                │
│                     ▼      ▼                                                │
│                ┌─────────────────┐                                         │
│                │  Weight Active  │ ────────────────────────────────────┐   │
│                │     Register    │                                      │   │
│                └────────┬────────┘                                      │   │
│                         │                                               │   │
│   pe_input_in ──────────┼───────────┐                                   │   │
│   (16-bit)              │           │                                   │   │
│                         ▼           ▼                                   │   │
│                     ┌───────────────────┐                               │   │
│                     │                   │                               │   │
│                     │   Multiplier      │                               │   │
│                     │   (16×16→32)      │                               │   │
│                     │                   │                               │   │
│                     └─────────┬─────────┘                               │   │
│                               │                                         │   │
│   pe_psum_in ─────────────────┼─────────┐                               │   │
│   (16-bit)                    │         │                               │   │
│                               ▼         ▼                               │   │
│                           ┌───────────────────┐                         │   │
│                           │                   │                         │   │
│                           │     Adder         │                         │   │
│                           │   (32+16→32)      │                         │   │
│                           │                   │                         │   │
│                           └─────────┬─────────┘                         │   │
│                                     │                                   │   │
│                                     ▼                                   │   │
│                              ┌─────────────┐                            │   │
│                              │  Truncate   │                            │   │
│                              │  (32→16)    │                            │   │
│                              └──────┬──────┘                            │   │
│                                     │                                   │   │
│                                     ▼                                   │   │
│                            ┌───────────────┐                            │   │
│   pe_psum_out ◄────────────│  Output Reg  │                            │   │
│   (16-bit)                 └───────────────┘                            │   │
│                                                                         │   │
│   pe_weight_out ◄───────────────────────────────────────────────────────┘   │
│   (16-bit)                                                                  │
│                                                                             │
│   pe_input_out ◄──── (pe_input_in 延迟一拍)                                 │
│   (16-bit)                                                                  │
│                                                                             │
│   pe_valid_out ◄──── (pe_valid_in 延迟一拍)                                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 PE 接口定义

```systemverilog
module pe #(
    parameter DATA_WIDTH = 16  // Q8.8 定点数
)(
    // 时钟与复位
    input  logic                      clk,
    input  logic                      rst,
    
    // 使能控制
    input  logic                      pe_enabled,
    
    // 权重接口 (Weight Stationary)
    input  logic signed [DATA_WIDTH-1:0] pe_weight_in,   // 权重输入
    output logic signed [DATA_WIDTH-1:0] pe_weight_out,  // 权重输出 (传递给下一个PE)
    input  logic                      pe_accept_w_in,    // 接受权重信号
    input  logic                      pe_switch_in,      // 切换权重信号
    output logic                      pe_switch_out,     // 切换信号输出
    
    // 激活输入接口
    input  logic signed [DATA_WIDTH-1:0] pe_input_in,    // 激活输入
    output logic signed [DATA_WIDTH-1:0] pe_input_out,   // 激活输出 (传递给右边PE)
    input  logic                      pe_valid_in,       // 输入有效
    output logic                      pe_valid_out,      // 输出有效
    
    // 部分和接口
    input  logic signed [DATA_WIDTH-1:0] pe_psum_in,     // 部分和输入 (从上方)
    output logic signed [DATA_WIDTH-1:0] pe_psum_out     // 部分和输出 (向下)
);
```

### 2.3 PE 状态机

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PE 操作状态                                        │
└─────────────────────────────────────────────────────────────────────────────┘

                    ┌──────────────┐
                    │              │
          rst ────▶ │    IDLE      │
                    │              │
                    └──────┬───────┘
                           │
                           │ pe_accept_w_in = 1
                           ▼
                    ┌──────────────┐
                    │              │
                    │ LOAD_WEIGHT  │ ◄─── 权重加载到 shadow register
                    │              │
                    └──────┬───────┘
                           │
                           │ pe_switch_in = 1
                           ▼
                    ┌──────────────┐
                    │              │
                    │ WEIGHT_ACTIVE│ ◄─── 权重从 shadow 切换到 active
                    │              │
                    └──────┬───────┘
                           │
                           │ pe_valid_in = 1
                           ▼
                    ┌──────────────┐
                    │              │       MAC: psum_out = weight * input + psum_in
                    │   COMPUTE    │ ◄─── 每个时钟周期执行一次 MAC
                    │              │
                    └──────────────┘
                           │
                           │ pe_valid_in = 0
                           │
                           ▼
                      (等待下一次数据)
```

### 2.4 PE 时序图

```
          1   2   3   4   5   6   7   8   9   10  11  12
clk     __|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_|‾|_

rst     ‾‾‾|_________________________________________________

accept_w______|‾‾‾|__________________________________________
                ↑
                加载权重 W

weight_in______[W1]__________________________________________

switch  ______________|‾‾‾|__________________________________
                        ↑
                        切换权重

valid_in____________________|‾‾‾‾‾‾‾|________________________
                              ↑   ↑
                              A1  A2

input_in____________________[A1][A2]_________________________

psum_in _____________________[P1][P2]_________________________

psum_out_________________________[R1][R2]_____________________
                                  ↑   ↑
                                  W*A1+P1  W*A2+P2

valid_out__________________________|‾‾‾‾‾‾‾|__________________
```

### 2.5 PE 核心计算

```
MAC 运算:
    psum_out = weight_active * input_in + psum_in

定点数乘法 (Q8.8 × Q8.8):
    - 输入: 16-bit × 16-bit
    - 中间结果: 32-bit (Q16.16)
    - 截断: 取中间 16-bit (Q8.8)
    
    product_32bit = weight[15:0] * input[15:0]  // 32-bit
    product_16bit = product_32bit[23:8]          // 截断，保持 Q8.8
    
定点数加法:
    psum_out = product_16bit + psum_in  // 饱和处理
```

---

## 3. Systolic Array 详解

### 3.1 2×2 Systolic Array 架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        2×2 Weight Stationary Systolic Array                  │
└─────────────────────────────────────────────────────────────────────────────┘

    Weight Loading (从上方加载权重)
         │           │
         W0          W1
         │           │
         ▼           ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                                                                     │
    │    ┌───────────────┐         ┌───────────────┐                     │
    │    │               │         │               │                     │
A0 ─────▶│    PE[0,0]   │────────▶│    PE[0,1]   │─────▶ (输出向右)     │
    │    │               │  A0'    │               │                     │
    │    │  W0 固定      │         │  W1 固定      │                     │
    │    └───────┬───────┘         └───────┬───────┘                     │
    │            │ P[0,0]                  │ P[0,1]                       │
    │            ▼                         ▼                             │
    │    ┌───────────────┐         ┌───────────────┐                     │
    │    │               │         │               │                     │
A1 ─────▶│    PE[1,0]   │────────▶│    PE[1,1]   │─────▶ (输出向右)     │
    │    │               │  A1'    │               │                     │
    │    │  W2 固定      │         │  W3 固定      │                     │
    │    └───────┬───────┘         └───────┬───────┘                     │
    │            │ P[1,0]                  │ P[1,1]                       │
    │            ▼                         ▼                             │
    │         Output[0]                 Output[1]                        │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

数据流说明:
- 权重 (W): 从上方加载，固定在 PE 中 (Weight Stationary)
- 激活 (A): 从左侧流入，向右传递
- 部分和 (P): 从上方流入，向下累加
- 输出: 从底部输出最终结果
```

### 3.2 矩阵乘法映射

```
计算 C = A × B，其中:
    A: 2×2 矩阵 (激活)
    B: 2×2 矩阵 (权重)
    C: 2×2 矩阵 (输出)

权重矩阵 B 预加载到 PE:
    PE[0,0] ← B[0,0]    PE[0,1] ← B[0,1]
    PE[1,0] ← B[1,0]    PE[1,1] ← B[1,1]

激活矩阵 A 按对角线流入:
    Cycle 0: A[0,0] → PE[0,0]
    Cycle 1: A[0,1] → PE[0,0], A[1,0] → PE[1,0]
    Cycle 2: A[1,1] → PE[0,0] (已流过), A[1,1] → PE[1,0]
    ...

输出矩阵 C 从底部收集:
    C[i,j] = Σ A[i,k] × B[k,j]
```

### 3.3 Systolic Array 时序

```
Weight Loading Phase (权重加载):
┌────┬────┬────┬────┬────┬────┐
│ T0 │ T1 │ T2 │ T3 │ T4 │ T5 │
├────┼────┼────┼────┼────┼────┤
│Load│Load│Load│Load│Swch│    │
│W00 │W01 │W10 │W11 │    │    │
└────┴────┴────┴────┴────┴────┘

Compute Phase (计算阶段) - 2×2 矩阵乘法:
┌────┬────────────────────────┬────────────────────────┬────────────────────────┬────────────────────────┐
│时刻│      PE[0,0]           │      PE[0,1]           │      PE[1,0]           │      PE[1,1]           │
├────┼────────────────────────┼────────────────────────┼────────────────────────┼────────────────────────┤
│ T0 │ W00×A00+0              │ idle                   │ idle                   │ idle                   │
│ T1 │ W00×A01+0              │ W01×A00+P00            │ W10×A00+0              │ idle                   │
│ T2 │ idle                   │ W01×A01+P01            │ W10×A01+P10            │ W11×A00+P00            │
│ T3 │ idle                   │ idle                   │ idle                   │ W11×A01+P01            │
└────┴────────────────────────┴────────────────────────┴────────────────────────┴────────────────────────┘

总延迟 = 2N-1 个周期 (对于 N×N 阵列)
```

---

## 4. 定点数系统 Q8.8

### 4.1 Q8.8 格式说明

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            Q8.8 定点数格式                                   │
└─────────────────────────────────────────────────────────────────────────────┘

位宽: 16 bits (有符号)

    ┌───┬───────────────┬───────────────────────────────┐
    │ S │   Integer     │         Fraction              │
    │ 1 │   7 bits      │         8 bits                │
    └───┴───────────────┴───────────────────────────────┘
     15   14         8   7                            0

S: 符号位 (0=正, 1=负)
Integer: 整数部分 (-128 ~ +127)
Fraction: 小数部分 (精度 = 1/256 ≈ 0.00390625)

范围: -128.0 ~ +127.99609375
精度: 1/256 ≈ 0.00390625
```

### 4.2 定点数转换

```
浮点数 → Q8.8:
    Q8.8_value = round(float_value × 256)
    
    例: 1.5 → 1.5 × 256 = 384 = 0x0180
    例: -2.25 → -2.25 × 256 = -576 = 0xFDC0

Q8.8 → 浮点数:
    float_value = Q8.8_value / 256.0
    
    例: 0x0100 → 256 / 256 = 1.0
    例: 0xFF00 → -256 / 256 = -1.0

常用值:
    1.0  = 0x0100 (256)
    0.5  = 0x0080 (128)
    0.25 = 0x0040 (64)
    -1.0 = 0xFF00 (-256)
    0.0  = 0x0000 (0)
```

### 4.3 定点数运算

```systemverilog
// 乘法 (Q8.8 × Q8.8 → Q8.8)
function automatic logic signed [15:0] fp_mul(
    input logic signed [15:0] a,
    input logic signed [15:0] b
);
    logic signed [31:0] product;
    product = a * b;           // 32-bit 中间结果 (Q16.16)
    return product[23:8];      // 截断到 Q8.8
endfunction

// 加法 (Q8.8 + Q8.8 → Q8.8)
function automatic logic signed [15:0] fp_add(
    input logic signed [15:0] a,
    input logic signed [15:0] b
);
    logic signed [16:0] sum;
    sum = a + b;
    // 饱和处理
    if (sum > 32767) return 16'h7FFF;
    else if (sum < -32768) return 16'h8000;
    else return sum[15:0];
endfunction

// MAC (Multiply-Accumulate)
function automatic logic signed [15:0] fp_mac(
    input logic signed [15:0] weight,
    input logic signed [15:0] activation,
    input logic signed [15:0] psum
);
    return fp_add(fp_mul(weight, activation), psum);
endfunction
```

---

## 5. Control Unit 与 ISA

### 5.1 94-bit 指令格式

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          94-bit 指令格式                                     │
└─────────────────────────────────────────────────────────────────────────────┘

[93:90] opcode        - 4 bits  - 操作码
[89:74] weight_addr   - 16 bits - 权重地址
[73:58] act_addr      - 16 bits - 激活地址
[57:42] out_addr      - 16 bits - 输出地址
[41:26] rows          - 16 bits - 行数
[25:10] cols          - 16 bits - 列数
[9:0]   misc          - 10 bits - 其他参数

操作码定义:
    4'b0000 - NOP         无操作
    4'b0001 - LOAD_W      加载权重到 Systolic Array
    4'b0010 - LOAD_A      加载激活到缓存
    4'b0011 - MATMUL      执行矩阵乘法
    4'b0100 - STORE       存储结果
    4'b0101 - BIAS        添加偏置
    4'b0110 - RELU        ReLU 激活
    4'b0111 - TRAIN       训练模式 (反向传播)
```

### 5.2 Control Unit 状态机

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       Control Unit FSM                                       │
└─────────────────────────────────────────────────────────────────────────────┘

                         ┌──────────┐
              reset ────▶│   IDLE   │◄─────────────────┐
                         └────┬─────┘                  │
                              │                        │
                              │ new_instruction        │
                              ▼                        │
                         ┌──────────┐                  │
                         │  DECODE  │                  │
                         └────┬─────┘                  │
                              │                        │
           ┌──────────────────┼──────────────────┐     │
           │                  │                  │     │
           ▼                  ▼                  ▼     │
     ┌──────────┐      ┌──────────┐      ┌──────────┐ │
     │ LOAD_W   │      │ MATMUL   │      │  STORE   │ │
     │          │      │          │      │          │ │
     │ 加载权重  │      │ 矩阵乘法  │      │ 存储结果  │ │
     └────┬─────┘      └────┬─────┘      └────┬─────┘ │
          │                 │                  │      │
          │ done            │ done             │ done │
          │                 │                  │      │
          └─────────────────┴──────────────────┴──────┘
```

---

## 6. ECC SECDED 技术规格

### 6.1 Hamming(39,32) 编码

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     Hamming(39,32) SECDED 编码                               │
└─────────────────────────────────────────────────────────────────────────────┘

输入: 32-bit 数据 D[31:0]
输出: 39-bit 编码 C[38:0]

编码结构:
    C[38]    - 全局奇偶位 (P_overall)
    C[37:32] - 6个校验位 (P5, P4, P3, P2, P1, P0)
    C[31:0]  - 32位数据 (D[31:0])

校验位计算:
    P0 = D[0]^D[1]^D[3]^D[4]^D[6]^D[8]^D[10]^D[11]^D[13]^D[15]^D[17]^D[19]^D[21]^D[23]^D[25]^D[26]^D[28]^D[30]
    P1 = D[0]^D[2]^D[3]^D[5]^D[6]^D[9]^D[10]^D[12]^D[13]^D[16]^D[17]^D[20]^D[21]^D[24]^D[25]^D[27]^D[28]^D[31]
    P2 = D[1]^D[2]^D[3]^D[7]^D[8]^D[9]^D[10]^D[14]^D[15]^D[16]^D[17]^D[22]^D[23]^D[24]^D[25]^D[29]^D[30]^D[31]
    P3 = D[4]^D[5]^D[6]^D[7]^D[8]^D[9]^D[10]^D[18]^D[19]^D[20]^D[21]^D[22]^D[23]^D[24]^D[25]
    P4 = D[11]^D[12]^D[13]^D[14]^D[15]^D[16]^D[17]^D[18]^D[19]^D[20]^D[21]^D[22]^D[23]^D[24]^D[25]
    P5 = D[26]^D[27]^D[28]^D[29]^D[30]^D[31]
    
    P_overall = P0^P1^P2^P3^P4^P5^D[0]^D[1]^...^D[31]  // 所有位异或

检错纠错:
    syndrome = {P5', P4', P3', P2', P1', P0'}  // 接收后重新计算
    
    if (syndrome == 0 && P_overall' == P_overall):
        无错误
    elif (syndrome != 0 && P_overall' != P_overall):
        单比特错误，可纠正，错误位置 = syndrome
    elif (syndrome == 0 && P_overall' != P_overall):
        P_overall 本身出错，可纠正
    elif (syndrome != 0 && P_overall' == P_overall):
        双比特错误，检测到但不可纠正
```

### 6.2 ECC 模块接口

```systemverilog
module ecc_hamming_32b (
    input  logic        clk,
    input  logic        rst,
    
    // 编码接口
    input  logic [31:0] data_in,        // 原始数据
    input  logic        encode_en,       // 编码使能
    output logic [38:0] encoded_out,    // 编码后数据
    
    // 解码接口
    input  logic [38:0] encoded_in,     // 编码数据
    input  logic        decode_en,       // 解码使能
    output logic [31:0] data_out,       // 解码数据
    output logic        sec_error,       // 单比特错误 (已纠正)
    output logic        ded_error        // 双比特错误 (不可纠正)
);
```

### 6.3 ECC 时序

```
        1    2    3    4    5    6
clk  __|‾|__|‾|__|‾|__|‾|__|‾|__|‾|__

encode_en    |‾‾‾‾|
data_in      |D1  |
encoded_out       |E1  |              (1 周期延迟)

decode_en              |‾‾‾‾|
encoded_in             |E1  |
data_out                    |D1  |    (1 周期延迟)
sec_error                   |0/1 |
ded_error                   |0/1 |
```

---

## 7. Sparse 优化技术规格

### 7.1 Sparse PE 架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Sparse PE 架构                                      │
└─────────────────────────────────────────────────────────────────────────────┘

                 ┌─────────────────────────────────────────────────────────┐
                 │                                                         │
   weight_in ────┼──┬─────────────────────────────────────────────────────┐│
                 │  │                                                     ││
                 │  ▼                                                     ││
                 │ ┌──────────┐                                           ││
                 │ │ Zero     │                                           ││
                 │ │ Detect   │──┐                                        ││
                 │ └──────────┘  │                                        ││
                 │               │ is_zero_w                              ││
   input_in ─────┼──┬────────────┼────────────────────────────────────────┼┤
                 │  │            │                                        ││
                 │  ▼            │                                        ││
                 │ ┌──────────┐  │                                        ││
                 │ │ Zero     │  │                                        ││
                 │ │ Detect   │──┼──┐                                     ││
                 │ └──────────┘  │  │ is_zero_i                           ││
                 │               │  │                                     ││
                 │               ▼  ▼                                     ││
                 │            ┌────────┐                                  ││
                 │            │  OR    │──── skip_mac                     ││
                 │            └────────┘                                  ││
                 │                 │                                      ││
                 │                 ▼                                      ││
                 │            ┌────────┐     ┌────────────┐              ││
                 │            │  ICG   │────▶│    MAC     │              ││
                 │            │ (Clock │     │   Unit     │              ││
                 │            │ Gating)│     │            │              ││
                 │            └────────┘     └─────┬──────┘              ││
                 │                                 │                     ││
                 │                                 ▼                     ││
                 │            ┌────────────────────────────┐             ││
   psum_in ──────┼───────────▶│       MUX                  │             ││
                 │            │  skip_mac ? psum_in : mac  │             ││
                 │            └────────────┬───────────────┘             ││
                 │                         │                             ││
                 │                         ▼                             ││
   psum_out ◄────┼─────────────────────────┘                             ││
                 │                                                       ││
   weight_out ◄──┼───────────────────────────────────────────────────────┘│
                 │                                                         │
                 └─────────────────────────────────────────────────────────┘

功耗优化:
  - 当 weight 或 input 为零时，跳过 MAC 计算
  - 使用 ICG (Integrated Clock Gating) 门控 MAC 时钟
  - 预期功耗降低: 30-40% (稀疏度 50% 时)
```

### 7.2 Sparse PE 接口

```systemverilog
module pe_sparse #(
    parameter DATA_WIDTH = 16
)(
    input  logic                      clk,
    input  logic                      rst,
    input  logic                      pe_enabled,
    
    // 标准 PE 接口 (与原版相同)
    input  logic signed [DATA_WIDTH-1:0] pe_weight_in,
    output logic signed [DATA_WIDTH-1:0] pe_weight_out,
    input  logic signed [DATA_WIDTH-1:0] pe_input_in,
    output logic signed [DATA_WIDTH-1:0] pe_input_out,
    input  logic signed [DATA_WIDTH-1:0] pe_psum_in,
    output logic signed [DATA_WIDTH-1:0] pe_psum_out,
    input  logic                      pe_valid_in,
    output logic                      pe_valid_out,
    
    // Sparse 扩展接口
    output logic                      mac_skipped,     // MAC 被跳过
    output logic                      clk_gated        // 时钟被门控
);
```

### 7.3 Clock Gating 实现

```systemverilog
// ICG (Integrated Clock Gating) 单元
module clock_gate (
    input  logic clk,
    input  logic enable,
    input  logic test_enable,  // 测试模式旁路
    output logic gated_clk
);
    logic enable_latch;
    
    // 负边沿锁存使能信号 (避免毛刺)
    always_latch begin
        if (~clk)
            enable_latch <= enable | test_enable;
    end
    
    // 门控时钟
    assign gated_clk = clk & enable_latch;
endmodule
```

---

## 8. AXI 接口技术规格

### 8.1 AXI4-Lite 信号

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       AXI4-Lite 信号列表                                     │
└─────────────────────────────────────────────────────────────────────────────┘

写地址通道 (AW):
    AWADDR  [31:0]  - 写地址
    AWPROT  [2:0]   - 保护类型
    AWVALID         - 地址有效
    AWREADY         - 从设备就绪

写数据通道 (W):
    WDATA   [31:0]  - 写数据
    WSTRB   [3:0]   - 字节使能
    WVALID          - 数据有效
    WREADY          - 从设备就绪

写响应通道 (B):
    BRESP   [1:0]   - 响应 (00=OKAY, 10=SLVERR)
    BVALID          - 响应有效
    BREADY          - 主设备就绪

读地址通道 (AR):
    ARADDR  [31:0]  - 读地址
    ARPROT  [2:0]   - 保护类型
    ARVALID         - 地址有效
    ARREADY         - 从设备就绪

读数据通道 (R):
    RDATA   [31:0]  - 读数据
    RRESP   [1:0]   - 响应
    RVALID          - 数据有效
    RREADY          - 主设备就绪
```

### 8.2 TPU 寄存器映射

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       TPU 寄存器地址映射                                     │
└─────────────────────────────────────────────────────────────────────────────┘

基地址: 0x4000_0000

偏移地址    名称              描述
──────────────────────────────────────────────────────────
0x000       CTRL              控制寄存器
            [0]  - start      启动计算
            [1]  - abort      中止计算
            [7:4]- mode       工作模式

0x004       STATUS            状态寄存器
            [0]  - busy       忙标志
            [1]  - done       完成标志
            [2]  - error      错误标志
            [7:4]- state      当前状态

0x008       INTR_EN           中断使能
0x00C       INTR_STATUS       中断状态

0x010       WEIGHT_ADDR       权重基地址
0x014       ACT_ADDR          激活基地址
0x018       OUT_ADDR          输出基地址

0x020       DIM_M             矩阵 M 维度
0x024       DIM_N             矩阵 N 维度
0x028       DIM_K             矩阵 K 维度

0x100-0x1FF WEIGHT_BUF        权重缓存 (直接访问)
0x200-0x2FF ACT_BUF           激活缓存 (直接访问)
0x300-0x3FF OUT_BUF           输出缓存 (直接访问)
```

### 8.3 AXI Wrapper 模块

```systemverilog
module axi_tpu_wrapper #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 32
)(
    // AXI4-Lite Slave 接口
    input  logic                      aclk,
    input  logic                      aresetn,
    
    // 写地址通道
    input  logic [ADDR_WIDTH-1:0]     s_axi_awaddr,
    input  logic [2:0]                s_axi_awprot,
    input  logic                      s_axi_awvalid,
    output logic                      s_axi_awready,
    
    // 写数据通道
    input  logic [DATA_WIDTH-1:0]     s_axi_wdata,
    input  logic [DATA_WIDTH/8-1:0]   s_axi_wstrb,
    input  logic                      s_axi_wvalid,
    output logic                      s_axi_wready,
    
    // 写响应通道
    output logic [1:0]                s_axi_bresp,
    output logic                      s_axi_bvalid,
    input  logic                      s_axi_bready,
    
    // 读地址通道
    input  logic [ADDR_WIDTH-1:0]     s_axi_araddr,
    input  logic [2:0]                s_axi_arprot,
    input  logic                      s_axi_arvalid,
    output logic                      s_axi_arready,
    
    // 读数据通道
    output logic [DATA_WIDTH-1:0]     s_axi_rdata,
    output logic [1:0]                s_axi_rresp,
    output logic                      s_axi_rvalid,
    input  logic                      s_axi_rready,
    
    // TPU 核心接口
    output logic                      tpu_start,
    input  logic                      tpu_done,
    input  logic                      tpu_busy,
    // ... 其他信号
);
```

---

## 9. 时序约束与 PPA 目标

### 9.1 时序目标

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           时序约束                                           │
└─────────────────────────────────────────────────────────────────────────────┘

目标频率: 200 MHz (周期 = 5 ns)

时钟定义:
    create_clock -name clk -period 5.0 [get_ports clk]

输入延迟:
    set_input_delay -clock clk 1.0 [all_inputs]

输出延迟:
    set_output_delay -clock clk 1.0 [all_outputs]

关键路径:
    1. MAC 路径: multiplier → adder → register
    2. 控制路径: FSM → decoder → buffer_ctrl
    3. 数据路径: buffer → PE → buffer
```

### 9.2 PPA 目标

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PPA 目标                                           │
└─────────────────────────────────────────────────────────────────────────────┘

Performance (性能):
    - 峰值算力: 2×2×2×200MHz = 1.6 GOPS (INT8)
    - 扩展到 8×8: 8×8×2×200MHz = 25.6 GOPS (INT8)

Power (功耗):
    - 目标: < 100 mW (8×8 阵列)
    - Sparse 优化后: < 60 mW (稀疏度 50%)

Area (面积):
    - PE: ~500 门
    - 8×8 阵列: ~50,000 门
    - 完整 TPU: ~100,000 门

效率:
    - GOPS/W: > 250
    - GOPS/mm²: > 100 (28nm)
```

### 9.3 验证覆盖率目标

```
功能覆盖率:
    - 状态机覆盖: 100%
    - 分支覆盖: > 95%
    - 条件覆盖: > 90%

代码覆盖率:
    - 行覆盖: > 95%
    - 条件覆盖: > 90%
    - FSM 覆盖: 100%

断言覆盖率:
    - 所有断言触发: 100%
```

---

*文档版本: v1.0 | 更新时间: 2025-01-16*
